﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using FluentNHibernate.Cfg;
using NHibernate;
using NHibernate.Cfg;

namespace BlogWeb.Models.Infra {
    public class NHibernateHelper {

        private static ISessionFactory factoryNHibernate = CriarSessaoFactory();

        private static ISessionFactory CriarSessaoFactory() {
            var cfg = new Configuration();
            cfg.Configure();
            return Fluently.Configure(cfg)
                                    .Mappings(x => {
                                        x.FluentMappings
                                            .AddFromAssembly(
                                                        Assembly.GetExecutingAssembly());
                                    }).BuildSessionFactory();
        }

        public static ISession AbrirSessao() 
        {
            return factoryNHibernate.OpenSession();
        }
    }
}