﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BlogWeb.Models.Dominio;
using BlogWeb.Models.Infra;
using NHibernate;

namespace BlogWeb.Models.DAO {
    public class UsuarioDao {

        private	ISession _sessao;

		public UsuarioDao(ISession sessao){
            this._sessao = sessao;
        }

        public IList<Usuario> Listar() {
            //using (ISession sessao = NHibernateHelper.AbrirSessao()) {
                string hqlCommand = "select u from Usuario u";
                IQuery q = _sessao.CreateQuery(hqlCommand);
                return q.List<Usuario>();
            //}
        }

        public void Adicionar(Usuario usuario) {
            //using (ISession sessao = NHibernateHelper.AbrirSessao()) {
                using (ITransaction tx = _sessao.BeginTransaction()) {
                    _sessao.Save(usuario);
                    tx.Commit();
                }
            //}
        }

        public Usuario BuscarPorId(int id) {
            //using (ISession sessao = NHibernateHelper.AbrirSessao()) {
                return _sessao.Get<Usuario>(id);
            //}
        }

        public void Remover(Usuario usuario) {
            //using (ISession sessao = NHibernateHelper.AbrirSessao()) {
                ITransaction tx = _sessao.BeginTransaction();
                _sessao.Delete(usuario);
                tx.Commit();
           // }
        }

        public void Atualizar(Usuario usuario) {
            //using (ISession sessao = NHibernateHelper.AbrirSessao()) {
                ITransaction tx = _sessao.BeginTransaction();
                _sessao.Merge(usuario);
                tx.Commit();
            //}
        }

        public Usuario Buscar(string login, string senha) { 
            string hql = "select	u	from	Usuario	u	where	" + "u.Login	=	:login	and	u.Password	=	:senha"; 
            IQuery query = _sessao.CreateQuery(hql); 
            query.SetParameter("login", login); 
            query.SetParameter("senha", senha); 
            return query.UniqueResult<Usuario>(); } 
    }
}
    