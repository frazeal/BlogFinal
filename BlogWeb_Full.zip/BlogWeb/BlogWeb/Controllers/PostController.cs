﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BlogWeb.Filters;
using BlogWeb.Models;
using BlogWeb.Models.DAO;
using BlogWeb.Models.Dominio;
using BlogWeb.ViewModels;

namespace BlogWeb.Controllers {
    
    //[AutorizacaoFilter]
    [Authorize]
    public class PostController : Controller {

        private PostDao dao;
        private UsuarioDao usuarioDao;

        public PostController(PostDao dao, UsuarioDao usuarioDao) {
            this.dao = dao;
            this.usuarioDao = usuarioDao;
        }

        // GET: Post
        [Route("posts", Name = "ListarPosts")] 
        public ActionResult Index() {
            //var dao = new PostDao();
            //ViewBag.Posts = dao.Listar();
            IList<Post> posts = dao.Listar();

           // UsuarioDao usuarioDao = new UsuarioDao();
            ViewBag.Usuarios = usuarioDao.Listar();

            return View(posts);
        }

        public ActionResult Form() {
            //ViewBag.Post = new Post();
            //ViewData["Post"] = new Post();
           // UsuarioDao usuarioDao = new UsuarioDao();
            ViewBag.Usuarios = usuarioDao.Listar();
            return View();
        }

        [HttpPost]
        //public ActionResult Adicionar(string titulo, string conteudo, DateTime? dataPublicacao, bool publicado) 
        public ActionResult Adicionar(PostModel viewModel) {
            //var post = new Post() {
            //    Titulo = titulo,
            //    Conteudo = conteudo,
            //    DataPublicacao = dataPublicacao,
            //    Publicado = publicado
            //};
            if (viewModel.Publicado && !viewModel.DataPublicacao.HasValue) {
                ModelState.AddModelError("post.Invalido", "Posts publicados	precisam ter uma data");
            }

            if (ModelState.IsValid) {
                Post post = viewModel.CriarPost();
                //var dao = new PostDao();
                dao.Adicionar(post);
                return RedirectToAction("Index", "Post");
            }
            else {
                //ViewBag.Post = post;
                //ViewData["Post"] = post;
                //UsuarioDao usuarioDao = new UsuarioDao();
                ViewBag.Usuarios = usuarioDao.Listar();
                return View("Form", viewModel);
            }
        }

        public ActionResult Remover(int id) {
           // PostDao dao = new PostDao();
            Post post = dao.BuscarPorId(id);
            dao.Remover(post);
            return RedirectToAction("Index");
        }

        [Route("posts/{id}", Name = "VisualizarPost")]
        public ActionResult Visualizar(int id) {
            //PostDao dao = new PostDao();
            //UsuarioDao usuarioDao = new UsuarioDao();

            Post post = dao.BuscarPorId(id);
            PostModel viewModel = new PostModel(post);

            return View(viewModel);
        }

        [HttpPost]
        public ActionResult Alterar(PostModel viewModel) {
            if (ModelState.IsValid) {
                //PostDao dao = new PostDao();
                Post post = viewModel.CriarPost();
                dao.Atualizar(post);
                return RedirectToAction("Index");
            }
            else {
                //UsuarioDao usuarioDao = new UsuarioDao();
                ViewBag.Usuarios = usuarioDao.Listar();
                return View("Visualizar", viewModel);
            }
        }
    }
}