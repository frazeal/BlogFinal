﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BlogWeb.Models.DAO;

namespace BlogWeb.Controllers
{
    [AllowAnonymous]
    public class MenuController : Controller
    {
        private UsuarioDao _usuarioDao;
        public MenuController(UsuarioDao u) {
            this._usuarioDao = u;
        }
        // GET: Menu
        public ActionResult Index()
        {
            ViewBag.Autores = _usuarioDao.Listar();
            return PartialView();
        }
    }
   
}