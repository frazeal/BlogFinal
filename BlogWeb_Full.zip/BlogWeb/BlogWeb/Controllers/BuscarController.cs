﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BlogWeb.Models.DAO;
using BlogWeb.Models.Dominio;

namespace BlogWeb.Controllers
{
    public class BuscarController : Controller
    {
        private PostDao _postDao;
        public BuscarController(PostDao p) {
            this._postDao = p;
        }
        // GET: Buscar
        public ActionResult Index()
        {
            return View();
        }

        [Route("Buscar/Autor/{nomeAutor}", Name="BuscarPorAutor")]
        public ActionResult BuscarPorAutor(string nomeAutor) { 
            IList<Post> resultado = _postDao.ListarPublicadosDoAutor(nomeAutor); 
            return View(resultado); 
        } 
    }
}