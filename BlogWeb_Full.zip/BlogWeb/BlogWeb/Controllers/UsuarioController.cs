﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using BlogWeb.Filters;
using BlogWeb.Models.DAO;
using BlogWeb.Models.Dominio;
using WebMatrix.WebData;

namespace BlogWeb.Controllers
{
    //[AutorizacaoFilter]
    [Authorize]
    public class UsuarioController : Controller
    {

        private PostDao dao;
        private UsuarioDao usuarioDao;

        public UsuarioController(PostDao dao, UsuarioDao usuarioDao) {
            this.dao = dao;
            this.usuarioDao = usuarioDao;
        }

        // GET: Usuario
        [Route("usuarios", Name= "ListarUsuarios")]
        public ActionResult Index()
        {
            //UsuarioDao usuarioDao = new UsuarioDao();
            IList<Usuario> usuarios = usuarioDao.Listar();
            return View(usuarios);
        }

        public ActionResult Form() 
        {
            return View();
        }

        [HttpPost]
        public ActionResult Adicionar(Usuario usuario) 
        {
            if (String.IsNullOrWhiteSpace(usuario.Email)) {
                ModelState.AddModelError("usuario.Invalido", "Usuário precisa ter um e-mail válido.");
            }

            if (ModelState.IsValid) {
                
                try {
                    //usuarioDao.Adicionar(usuario);
                    WebSecurity.CreateUserAndAccount(usuario.Login, usuario.Password, new { Email = usuario.Email, Nome = usuario.Nome }, false);
                    return RedirectToAction("Index");
                }
                catch (MembershipCreateUserException e) {
                    ModelState.AddModelError("usuario.Invalido", e.Message);
                    throw;
                }
            }
            else {
                return View("Form", usuario);
            }
        }

        public ActionResult Remover(int id) 
        {
            //UsuarioDao usuarioDao = new UsuarioDao();
            Usuario usuario = usuarioDao.BuscarPorId(id);
            usuarioDao.Remover(usuario);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult Alterar(Usuario usuario) {
            if (ModelState.IsValid) {
                //var usuarioDao = new UsuarioDao();
                usuarioDao.Atualizar(usuario);
                return RedirectToAction("Index");
            }
            else {
                return View("Visualizar", usuario);
            }
        }

        [Route("usuarios/{id}", Name = "VisualizarUsuario")]
        public ActionResult Visualizar(int id) {
            //UsuarioDao usuarioDao = new UsuarioDao();
            Usuario usuario = usuarioDao.BuscarPorId(id);
            return View(usuario);
        }
    }
}