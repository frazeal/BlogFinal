﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BlogWeb.Models.DAO;
using BlogWeb.Models.Dominio;

namespace BlogWeb.Controllers
{
    public class HomeController : Controller
    {
        private readonly PostDao dao;

        public HomeController(PostDao postDao) {
            this.dao = postDao;
        }

        // GET: Home
        public ActionResult Index()
        {
            IList<Post> posts = dao.Listar().Where(x => x.Publicado == true).OrderByDescending(x => x.DataPublicacao).ToList();
            //dao.ListarPublicados();
            return View(posts);
        }
    }
}