﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BlogWeb.Models.DAO;
using BlogWeb.Models.Dominio;
using WebMatrix.WebData;

namespace BlogWeb.Controllers
{
    [AllowAnonymous]
    public class LoginController : Controller
    {
        private UsuarioDao _usuarioDao;

        public LoginController(UsuarioDao u) {
            this._usuarioDao = u;
            if (!WebSecurity.Initialized) { 
                WebSecurity.InitializeDatabaseConnection("blog", "Usuario", "Id", "Login", true); } 
        }
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Autenticar(string login, string senha) { 
            //Usuario usuario = _usuarioDao.Buscar(login, senha); 
            //if (usuario != null) { 
            //    Session["usuario"] = usuario; 
            //    return RedirectToAction("Index", "Post"); 
            //} 
            if(WebSecurity.Login(login, senha)){
                return RedirectToAction("Index", "Post");
            }
            else { 
                ModelState.AddModelError("login.Invalido", "Login ou senha incorretos"); 
                return View("Index"); 
            } 
        }

        public ActionResult Logout() {
            WebSecurity.Logout();
            return RedirectToAction("Index");
        }
    }
}