﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using BlogWeb.Models.Dominio;

namespace BlogWeb.ViewModels {
    public class PostModel {

        #region Propriedades

            public int Id { get; set; }

            [Required(ErrorMessage = "Por favor preencha o campo")]
            [StringLength(20, ErrorMessage = "Digite no	máximo 20 caracteres")]
            public string Titulo { get; set; }

            public string Conteudo { get; set; }

            [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
            public DateTime? DataPublicacao { get; set; }

            public bool Publicado { get; set; }

            public int? AutorId { get; set; }

        #endregion

        #region Construtores

            public PostModel(Post post) {
                this.Id = post.Id; 
                this.Titulo = post.Titulo; 
                this.Conteudo = post.Conteudo; 
                this.Publicado = post.Publicado; 
                this.DataPublicacao = post.DataPublicacao; 
            
                if (post.Autor != null) { 
                    this.AutorId = post.Autor.Id; 
                } 
            }

            public PostModel() {

            }

        #endregion

        #region Metodos

            public Post CriarPost() {
                    
                Post post = new Post() {
                    Id = this.Id,
                    Titulo = this.Titulo,
                    Conteudo = this.Conteudo,
                    Publicado = this.Publicado,
                    DataPublicacao = this.DataPublicacao
                };

                if (this.AutorId != 0) {
                    Usuario autor = new Usuario() {
                        Id = (int) this.AutorId
                    };
                    post.Autor = autor;
                }

                return post;
            }

        #endregion

    }
}